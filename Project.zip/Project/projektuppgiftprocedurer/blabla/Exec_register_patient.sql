USE [Clinic]
GO
--delete from patient
DECLARE @RC int
DECLARE @p_medicalId char(9)
DECLARE @p_patientFirstName varchar(20)
DECLARE @p_patientLastName varchar(20)
DECLARE @p_gender varchar(20)
DECLARE @p_adress varchar(100)
DECLARE @p_patientPhoneNumber varchar(15)
DECLARE @p_birthDate date
DECLARE @p_errorMessage varchar(100)

	Set @p_medicalId = ''
	Set @p_patientFirstName ='Thomas'
	Set @p_patientLastName = 'Engstr�m'
	Set @p_gender = 'Male'
	Set @p_adress = 'Stens�kerv�gan 112 23833 Oxie'
	Set @p_patientPhoneNumber = '0707313115'
	Set @p_birthDate = '1962-10-25'
	Set @p_errorMessage = '99'


While @p_medicalId <> '999999999' --@p_errorMessage <> ''
Begin
	Set @p_medicalId =	( 
		case @p_medicalId	 when '' then '0b0000001'
							 when '0b0000001' then 'a00000001'
							 when 'a00000001' then '000000002'
							 when '000000002' then '1234'
							 when '1234' then '000000004'
							 else '999999999'
	end)



	Set @p_errorMessage = NULL

	-- TODO: Set parameter values here.

	EXECUTE @RC = [dbo].[register_patient] 
	--EXECUTE @RC = [dbo].[register_patient_TryCatch] 
	   @p_medicalId
	  ,@p_patientFirstName
	  ,@p_patientLastName
	  ,@p_gender
	  ,@p_adress
	  ,@p_patientPhoneNumber
	  ,@p_birthDate
	  ,@p_errorMessage OUTPUT


	select @p_errorMessage ErrorMessage
	select * from patient
end;

