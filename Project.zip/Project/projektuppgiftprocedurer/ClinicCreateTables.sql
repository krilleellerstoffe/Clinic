create table [Admin] (
	AdminId char(5) primary key not null,
	AdminFirstName varchar(20) not null,
	AdminLastName varchar(20) not null
);

create table Specialization (
	SpecializationType varchar(20) primary key not null,
	VisitingCost decimal not null
);

create table Doctor (
	EmployeeId char(5) primary key not null,
	DoctorFirstName varchar(20) not null,
	DoctorLastName varchar(20) not null,
	SpecializationType varchar(20) foreign key references specialization(SpecializationType) not null,
	DoctorPhoneNumber varchar(15) not null
);

create table AvailableTime (
	EmployeeId char(5) foreign key references Doctor(EmployeeId) not null,
	AvailableTime datetime  not null
	primary key(EmployeeId, AvailableTime)
);

create table Patient (
	MedicalId char(9) primary key not null,
	PatientFirstName varchar(20) not null,
	PatientLastName varchar(20) not null,
	Gender varchar(20) not null,
	Adress varchar(100) not null,
	PatientPhoneNumber varchar(15) not null,
	BirthDate date not null,
	RegistrationDate date not null
);

create table Appointment (
	EmployeeId char(5) foreign key references Doctor(EmployeeId) not null ,
	MedicalId char(9) foreign key references Patient(MedicalId) not null,
	AppointmentDateTime datetime not null
	primary key(EmployeeId, MedicalId, AppointmentDateTime)
);

create table MedicalRecord (
	RecordId char(5) primary key not null,
	EmployeeId char(5) foreign key references Doctor(EmployeeId) not null ,
	MedicalId char(9) foreign key references Patient(MedicalId) not null,
	Diagnosis varchar(100) not null,
	[Description] varchar(1000) not null,
	CreationDate date not null
);

create table Drugs (
	RecordId char(5) foreign key references MedicalRecord(RecordId) not null,
	NameOfDrug varchar(30) not null
	primary key(RecordId, NameOfDrug)
);