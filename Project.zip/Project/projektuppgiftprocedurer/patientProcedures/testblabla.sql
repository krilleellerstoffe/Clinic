USE [Clinic]
GO

declare @p_errorMessage varchar(100)

DECLARE	@return_value int

EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'a00000002',@p_patientFirstName = N'Adam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25',@p_errorMessage = @p_errorMessage OUTPUT
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'000000002',@p_patientFirstName = N'Badam',@p_patientLastName = N'Svensson',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'008000003',@p_patientFirstName = N'Cadam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'034000001',@p_patientFirstName = N'Dadam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'000540001',@p_patientFirstName = N'Edam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'234000001',@p_patientFirstName = N'Adam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'076570001',@p_patientFirstName = N'Badam',@p_patientLastName = N'Svensson',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'223000001',@p_patientFirstName = N'Cadam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'054000001',@p_patientFirstName = N'Dadam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'344004001',@p_patientFirstName = N'Edam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'043500001',@p_patientFirstName = N'Adam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'055550001',@p_patientFirstName = N'Badam',@p_patientLastName = N'Svensson',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'000666001',@p_patientFirstName = N'Cadam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'088888001',@p_patientFirstName = N'Dadam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'
--EXEC	@return_value = [dbo].[register_patient] @p_medicalId = N'065400001',@p_patientFirstName = N'Edam',@p_patientLastName = N'Engström',@p_gender = N'Male',@p_adress = N'Kolsyregatan 20 Limhamn',@p_patientPhoneNumber = N'0701234567',@p_birthDate = '1967-10-25'

select @p_errorMessage

SELECT	'Return Value' = @return_value

GO

select dbo.fullname(PatientFirstName, PatientLastName), * from Patient order by MedicalId

--delete from Patient

SELECT ISNUMERIC('45.657'); 