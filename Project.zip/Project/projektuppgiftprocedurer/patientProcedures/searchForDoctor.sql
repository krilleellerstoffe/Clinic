alter procedure search_for_doctor_with_specialization
	@p_specialization_type varchar(20)
	as
	begin try
		
		set @p_specialization_type = @p_specialization_type + '%'

		--checks if there's any doctors with the specialization, throws error if not
		if not exists (select 1 from Doctor where SpecializationType like @p_specialization_type)
		begin
			raiserror('There''s no doctors with that specialization type.', 16, 1)
		end

		select d.EmployeeId, d.[Name], d.Specialization, d.Cost, d.Number
		from doctor_and_specialization d
		where d.Specialization like @p_specialization_type
	end try
	begin catch
		throw
	end catch