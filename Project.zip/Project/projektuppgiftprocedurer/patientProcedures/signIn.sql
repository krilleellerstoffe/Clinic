alter procedure patient_sign_in
@p_medicalId char(9),
@p_message varchar(100) output
as
begin
	begin try

		--check if medical id exists
		if exists (select 1 from Patient p where @p_medicalId = p.MedicalId)
		begin
			raiserror('Signed-in.', 10, 1) --10 = no error
		end
		--send error message if medical id doesn't exist
		else
		begin
			raiserror('Error: Login failed. MedicalID doesn''t exist.', 16, 1) --16 = error, goes to catch
		end

	end try
	begin catch
		throw
	end catch
end