create procedure show_doctor_and_specialization
	as
	select * from doctor_and_specialization