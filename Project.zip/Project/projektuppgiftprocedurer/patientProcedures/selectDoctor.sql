alter procedure select_doctor
	@p_employee_id char(5),
	@error_flag char(1) output
	as
	begin try
		if not exists (select * from Doctor d where d.EmployeeId = @p_employee_id)
		begin
		 raiserror('There''s no doctors with that employee id.', 16, 1)
		end

		select * from Doctor d
		where d.EmployeeId = @p_employee_id

	end try
	begin catch
		throw
	end catch