alter procedure view_patient_info
@p_medicalId char(9)
as
begin try

	if not exists (select 1 from Patient p where @p_medicalId = p.MedicalId)
	begin
		raiserror('There''s no patient with that medical id.', 16, 1)
	end

	select MedicalId, FirstName, LastName, Gender, Adress, PhoneNumber, BirthDate, RegistrationDate 
	from Patient p
	where @p_medicalId = p.MedicalId

end try
begin catch
	throw
end catch