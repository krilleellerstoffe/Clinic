alter procedure show_available_times_for_doctor
@d_employee_id char(5),
@error_flag char(1) output
as
set datefirst 1
declare @day_in_week int
declare @first_date_next_week date
declare @last_date_next_week date
set @day_in_week = datepart(dw, getdate())
set @first_date_next_week = getdate() - @day_in_week + 7 + 1
set @last_date_next_week = dateadd(day, 5, @first_date_next_week)

set @error_flag = ''

if exists (select * from Doctor d where d.EmployeeId = @d_employee_id)
begin
	select EmployeeId, AvailableDate as [Date], convert(varchar(5), cast(AvailableTime as time), 108) as [Time]
	from AvailableTime a
	where a.EmployeeId = @d_employee_id and a.AvailableDate between @first_date_next_week and @last_date_next_week
end
else
begin
	set @error_flag = '1'
end




select convert(varchar(5), cast(getdate() as time), 108)


insert into Specialization (SpecializationType, VisitingCost)
values('Dentist', 200),
	  ('Surgeon', 500),
	  ('Pediatrician', 200)

insert into Doctor (EmployeeId, FirstName, LastName, SpecializationType, PhoneNumber)
values(
	'12345',
	'Gregory',
	'House',
	'Surgeon',
	'0702345'),
	('54321',
	'Jekyll',
	'Hyde',
	'Dentist',
	'0708768');

execute insert_doctor '12345','Gregory','House', '0702345', 'Surgeon'

delete from Doctor
delete from AvailableTime

insert into AvailableTime (EmployeeId, AvailableTime)
values(

alter procedure add_available_times
@p_employee_id char(5)
as
begin
	declare @current_day date
	declare @start_time time
	set datefirst 1
	set @current_day = GETDATE()
	--loop for all days
	while @current_day <= '2020-12-24'
	begin
		if(datepart(weekday, @current_day) between 1 and 5) --monday to friday
		begin
			set @start_time = '09:00'
			--loop for all workinghours
			while @start_time <= '10:30'
			begin
				insert into AvailableTime (EmployeeId, AvailableDate, AvailableTime) values(@p_employee_id, @current_day, @start_time)
				set @start_time = DATEADD(MINUTE, 30, @start_time)
			end --while
		end
		set @current_day = DATEADD(DAY, 1, @current_day)	
	end --while
end



select convert(time, @current_daytime)

--delete from AvailableTime

