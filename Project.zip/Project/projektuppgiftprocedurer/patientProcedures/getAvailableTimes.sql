alter procedure show_avaiable_times_for_doctor
@d_employee_id char(5),
@message char(1) output
as
set @message = ''
if exists (select * from Doctor d where d.EmployeeId = @d_employee_id)
begin
	select *
	from AvailableTime a
	where a.EmployeeId = @d_employee_id
end
else
begin
	set @message = '1'
end

insert into Specialization (SpecializationType, VisitingCost)
values('Dentist', 200),
	  ('Surgeon', 500),
	  ('Pediatrician', 200)

insert into Doctor (EmployeeId, FirstName, LastName, SpecializationType, PhoneNumber)
values(
	'12345',
	'Gregory',
	'House',
	'Surgeon',
	'0702345'),
	('54321',
	'Jekyll',
	'Hyde',
	'Dentist',
	'0708768');

execute insert_doctor '12345','Gregory','House', '0702345', 'Surgeon'

delete from Doctor
delete from AvailableTime

insert into AvailableTime (EmployeeId, AvailableTime)
values(

alter procedure add_available_times
@p_employee_id char(5)
as
begin
	declare @max_date date
	declare @current_day date
	declare @start_time time
	set datefirst 1
	set @current_day = GETDATE()
	set @max_date =  dateadd(day, 180, @current_day)
	--loop for all days
	while @current_day <= @max_date
	begin
		if(datepart(weekday, @current_day) between 1 and 5) --monday to friday
		begin
			set @start_time = '09:00'
			--loop for all workinghours
			while @start_time <= '10:30'
			begin
				insert into AvailableTime (EmployeeId, AvailableDate, AvailableTime) values(@p_employee_id, @current_day, @start_time)
				set @start_time = DATEADD(MINUTE, 30, @start_time)
			end --while
		end
		set @current_day = DATEADD(DAY, 1, @current_day)	
	end --while
end



select convert(time, @current_daytime)

--delete from AvailableTime

