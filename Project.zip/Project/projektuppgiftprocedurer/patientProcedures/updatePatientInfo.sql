ALTER procedure [dbo].[update_patient_info]
@p_medicalId char(9),
@p_newfirstname varchar(20),
@p_newlastname varchar(20),
@p_newgender varchar(20),
@p_newadress varchar(100),
@p_newphonenumber varchar(15),
@p_newbirthdate date
as
begin try
	begin transaction

	--checks if there's any patients with the medical id, throws error if not.
	if not exists (select 1 from Patient p where @p_medicalId = p.MedicalId)
	begin
		raiserror('No patient with that medical id exists.', 16, 1)
	end

	update Patient
	set FirstName = @p_newfirstname,
		LastName = @p_newlastname,
		Gender = @p_newgender,
		Adress = @p_newadress,
		PhoneNumber = @p_newphonenumber,
		BirthDate = @p_newbirthdate
	where MedicalId = @p_medicalId

	commit transaction
end try
begin catch
	rollback transaction;
	throw
end catch