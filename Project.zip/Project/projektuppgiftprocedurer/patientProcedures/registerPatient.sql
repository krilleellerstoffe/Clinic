USE [Clinic]
GO
/****** Object:  StoredProcedure [dbo].[register_patient]    Script Date: 2020-12-20 15:44:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [dbo].[register_patient]
	@p_medicalId char(9),
	@p_patientFirstName varchar(20),
	@p_patientLastName varchar(20),
	@p_gender varchar(20),
	@p_adress varchar(100),
	@p_patientPhoneNumber varchar(15),
	@p_birthDate date
	as
	begin
		begin try
			begin transaction

				declare @p_registrationDate date = getdate()

				if TRY_CONVERT (int, @p_medicalId) is null
				begin
					raiserror('Medical id must be numeric.', 16, 1)
				end

				if len(@p_medicalId) <> 9
				begin
					raiserror('Medical id must be 9 characters.', 16, 1)
				end

				insert into Patient (MedicalId, FirstName, LastName, Gender, Adress, PhoneNumber, BirthDate, RegistrationDate)
				values (@p_medicalId, @p_patientFirstName, @p_patientLastName, @p_gender, @p_adress, @p_patientPhoneNumber, @p_birthDate, @p_registrationDate)

			commit transaction
		end try
		begin catch
			rollback transaction;
			throw
		end catch
	end