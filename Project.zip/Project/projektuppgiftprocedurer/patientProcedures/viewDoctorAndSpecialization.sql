alter view doctor_and_specialization as
	select EmployeeId, d.FirstName + ' ' + d.LastName as [Name], s.SpecializationType as Specialization, s.VisitingCost as  Cost, d.PhoneNumber as Number
	from Doctor d join Specialization s
	on d.SpecializationType = s.SpecializationType