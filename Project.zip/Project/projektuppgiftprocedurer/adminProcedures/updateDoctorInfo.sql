alter procedure update_doctor_info
@p_employee_id char(5),
@p_newfirstname varchar(20),
@p_newlastname varchar(20),
@p_specialization_type varchar(20),
@p_newphonenumber varchar(15)
as
begin try
	begin transaction

	--checks if there's any patients with the medical id, throws error if not.
	if not exists (select 1 from Doctor where EmployeeId = @p_employee_id)
	begin
		raiserror('No doctor with that emplyee id exists.', 16, 1)
	end

	update Doctor
	set FirstName = @p_newfirstname,
		LastName = @p_newlastname,
		SpecializationType = @p_specialization_type,
		PhoneNumber = @p_newphonenumber
	where EmployeeId = @p_employee_id

	commit transaction
end try
begin catch
	rollback transaction;
	throw
end catch