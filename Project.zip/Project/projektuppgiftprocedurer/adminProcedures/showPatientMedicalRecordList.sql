alter procedure show_patient_medical_record_list
	@p_medical_id char(9)
	as
	begin
		begin try

			--checks if there's any medical redcords for the patient, throws error if not
			if not exists (select 1 from MedicalRecord where MedicalId = @p_medical_id)
			begin
				raiserror('There are no medical records available for that patient.', 16, 1)
			end

			select RecordId, EmployeeId, MedicalId, Diagnosis, [Description], CreationDate
			from MedicalRecord m
			where m.MedicalId = @p_medical_id
			order by RecordId

		end try
		begin catch
			throw
		end catch
	end