alter procedure show_upcoming_appointments
	as
	begin
		begin try

			--checks if there's any upcoming appointments, throws error if not
			if not exists (select 1 from Appointment where AppointmentDate >= getdate())
			begin
				raiserror('There are no upcoming appointments.', 16, 1)
			end

			select EmployeeId, MedicalId, AppointmentDate, AppointmentTime
			from Appointment a
			where a.AppointmentDate >= getdate()

		end try
		begin catch
			throw
		end catch
	end