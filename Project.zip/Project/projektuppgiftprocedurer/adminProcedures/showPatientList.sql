alter procedure show_patient_list
	as
	begin
		begin try

			--checks if there's any registered patients, throws error if not
			if not exists (select 1 from Patient)
			begin
			 raiserror('There are no registered patients.', 16, 1)
			end

			select MedicalId, FirstName, LastName, Gender, Adress, PhoneNumber, BirthDate, RegistrationDate 
			from Patient

		end try
		begin catch
			throw
		end catch
	end