alter view view_patients_and_total_costs
	as
	select p.MedicalId, p.FirstName, p.LastName, p.Gender, p.Adress, p.PhoneNumber, p.BirthDate, p.RegistrationDate, sum(s.VisitingCost) as totalVisitingCosts
	from Patient p join Appointment a
	on p.MedicalId = a.MedicalId
	join Doctor d
	on a.EmployeeId = d.EmployeeId
	join Specialization s
	on d.SpecializationType = s.SpecializationType
	group by p.MedicalId, p.FirstName, p.LastName, p.Gender, p.Adress, p.PhoneNumber, p.BirthDate, p.RegistrationDate


insert into Appointment(EmployeeId, MedicalId, AppointmentDate, AppointmentTime)
values('12345', '123456789', '2020-12-28', '09:30')

select * from view_patients_and_total_costs