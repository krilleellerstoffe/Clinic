alter procedure insert_specialization (
	@p_specialization_type as varchar(20),
	@p_visiting_cost as decimal)
	as
	begin
		begin try

			begin transaction

			--checks if the specialization being added already exists, throws error if it does
			if exists (select 1 from Specialization where SpecializationType = @p_specialization_type)
			begin
				raiserror('Error: That specialization aleady exists.', 16, 1)
			end

			insert into Specialization(SpecializationType, VisitingCost)
			values (@p_specialization_type, @p_visiting_cost);

			commit transaction

		end try
		begin catch
			rollback transaction;
			throw
		end catch
	end
