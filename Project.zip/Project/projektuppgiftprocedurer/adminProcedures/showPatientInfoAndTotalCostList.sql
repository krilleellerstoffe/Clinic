alter procedure show_patient_and_total_cost_list
	as
	begin
		begin try

			--checks if theres any rows in the view, throws error if not
			if not exists(select 1 from view_patients_and_total_costs)
			begin
				raiserror('There are no records available.', 16, 1)
			end

			select MedicalId ,FirstName ,LastName ,Gender ,Adress ,PhoneNumber ,BirthDate ,RegistrationDate ,totalVisitingCosts
			from view_patients_and_total_costs

		end try
		begin catch
			throw
		end catch
	end