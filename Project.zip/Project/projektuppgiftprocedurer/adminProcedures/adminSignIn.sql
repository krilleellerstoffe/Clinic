alter procedure admin_sign_in
	@p_admin_id char(5)
	as 
	begin
		begin try

			--check if @p_admin_id exists in Doctor table
			if exists (select 1 from [Admin] a where a.AdminId = @p_admin_id)
			begin
				raiserror('Signed-in.', 10, 1)
			end
			--send error message if medical id doesn't exist
			else
			begin
				raiserror('Error: Login failed. AdminID doesn''t exist.', 16, 1) --16 = error, goes to catch
			end

		end try
		begin catch
			throw
		end catch
	end
