alter function next_employee_id ()
returns char(5)
begin
	declare @next_employee_id as char(5)

	set @next_employee_id = (select max(EmployeeId) + 1 from Doctor) --gets highest employeeId and adds 1
	if @next_employee_id is null
	begin
		set @next_employee_id = '1'
	end
	if @next_employee_id < 10
	begin
		set @next_employee_id = '0000' + @next_employee_id
	end
	else
	if @next_employee_id < 100
	begin
		set @next_employee_id = '000' + @next_employee_id
	end
	else
	if @next_employee_id < 1000
	begin
		set @next_employee_id = '00' + @next_employee_id
	end
	else
	if @next_employee_id < 10000
	begin
		set @next_employee_id = '0' + @next_employee_id
	end

	return @next_employee_id
end