USE [Clinic]
GO

ALTER TABLE [dbo].[AvailableTime] DROP CONSTRAINT [FK__Available__Emplo__31EC6D26]
GO

/****** Object:  Table [dbo].[AvailableTime]    Script Date: 2020-12-22 15:55:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AvailableTime]') AND type in (N'U'))
DROP TABLE [dbo].[AvailableTime]
GO

/****** Object:  Table [dbo].[AvailableTime]    Script Date: 2020-12-22 15:55:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AvailableTime](
	[EmployeeId] [char](5) NOT NULL,
	[AvailableDate] [date] NOT NULL,
	[AvailableTime] [time] not null
PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC,
	[AvailableDate] ASC,
	[AvailableTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AvailableTime]  WITH CHECK ADD FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Doctor] ([EmployeeId])
GO


