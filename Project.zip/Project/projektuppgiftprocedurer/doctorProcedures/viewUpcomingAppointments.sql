alter view view_upcoming_appointments as
	select p.MedicalId, p.FirstName + ' ' + p.LastName as PatientFullName, a.AppointmentDate, a.AppointmentTime
	from Doctor d join Appointment a
	on d.EmployeeId = a.EmployeeId
	join Patient p
	on p.MedicalId = a.MedicalId
