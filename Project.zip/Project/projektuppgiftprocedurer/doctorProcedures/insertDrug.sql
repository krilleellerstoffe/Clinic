alter procedure insert_drug
	@p_record_id char(5),
	@p_name_of_drug varchar(30)
	as
	begin
		begin try

			--checks if there's any medical record with the id available, throws error if not.
			if not exists (select 1 from MedicalRecord where RecordId = @p_record_id)
			begin
				raiserror('There are no medical records with that id available.', 16, 1)
			end

			begin transaction
			insert into Drug (RecordId, NameOfDrug)
			values(@p_record_id, @p_name_of_drug)

			commit transaction

		end try
		begin catch
			rollback transaction;
			throw
		end catch
	end