USE [Clinic]
GO

DECLARE	@return_value int

EXEC	@return_value = [dbo].[insert_doctor]
		@p_employee_id = N'21345',
		@p_first_name = N'Sven',
		@p_last_name = N'Svensson',
		@p_specialization = N'Dentist',
		@p_phone_number = N'0701239'
		

SELECT	'Return Value' = @return_value

GO
