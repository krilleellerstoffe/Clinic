alter procedure insert_medical_record (
	@p_record_id char(5),
	@p_medical_id char(9),
	@p_employee_id char(5),
	@p_diagnosis as varchar(255),
	@p_description as nvarchar(255))
	as
	begin
		declare @p_registrationDate date = getdate()

		declare @inserterror int
		set @inserterror = 0

		begin transaction
		

		insert into MedicalRecord (RecordId, MedicalId, EmployeeId, Diagnosis, [Description], CreationDate)
		values (@p_record_id, @p_medical_id, @p_employee_id, @p_diagnosis, @p_description, @p_registrationDate)
		set @inserterror = @@ERROR

		if @inserterror <> 0 
			begin 
				rollback transaction
			end
			else 
			begin 
				commit transaction
			end
		return @inserterror
	end
