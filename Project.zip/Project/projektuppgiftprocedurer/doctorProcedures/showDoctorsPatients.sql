alter procedure show_doctors_patients
	@p_employee_id char(5)
	as
	begin
		select p.MedicalId, p.FirstName, p.LastName, p.Gender, p.Adress, p.PhoneNumber, p.BirthDate, p.RegistrationDate
		from Appointment a join Patient p
		on a.MedicalId = p.MedicalId
		where a.EmployeeId = @p_employee_id
	end