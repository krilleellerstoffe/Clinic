alter procedure insert_medical_record (
	@p_medical_id char(9),
	@p_employee_id char(5),
	@p_diagnosis as varchar(255),
	@p_description as varchar(255))
	as
	begin
		begin try

			declare @p_registrationDate date = getdate()
			declare @next_record_id as char(5)

			begin transaction

			if not exists (select 1 from Doctor where EmployeeId = @p_employee_id)
			begin
				raiserror('There''s no doctor with that employee id.', 16, 1)
			end

			if not exists (select 1 from Patient where MedicalId = @p_medical_id)
			begin
				raiserror('There''s no patient with that medical id.', 16, 1)
			end

			set @next_record_id = (select dbo.next_record_id())
		
			insert into MedicalRecord (RecordId, MedicalId, EmployeeId, Diagnosis, [Description], CreationDate)
			values (@next_record_id, @p_medical_id, @p_employee_id, @p_diagnosis, @p_description, @p_registrationDate)

			commit transaction

		end try
		begin catch
			rollback transaction;
			throw
		end catch
	end
