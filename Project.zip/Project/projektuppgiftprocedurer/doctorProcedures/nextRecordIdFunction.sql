alter function next_record_id ()
returns char(5)
begin
	declare @next_record_id as char(5)

	set @next_record_id = (select max(RecordId) + 1 from MedicalRecord) --gets highest RecordId and adds 1
	if @next_record_id is null
	begin
		set @next_record_id = '1'
	end
	if @next_record_id < 10
	begin
		set @next_record_id = '0000' + @next_record_id
	end
	else
	if @next_record_id < 100
	begin
		set @next_record_id = '000' + @next_record_id
	end
	else
	if @next_record_id < 1000
	begin
		set @next_record_id = '00' + @next_record_id
	end
	else
	if @next_record_id < 10000
	begin
		set @next_record_id = '0' + @next_record_id
	end

	return @next_record_id
end