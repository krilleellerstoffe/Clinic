alter procedure get_upcoming_appointments
	@p_employee_id char(5)
	as
	begin
		begin try

			--checks if theres any upcoming appointments for the doctor, throws error if not
			if not exists (select 1 from view_upcoming_appointments where MedicalId = @p_employee_id)
			begin
				raiserror('There are no upcoming appointments.', 16, 1)
			end

			select MedicalId, PatientFullName, AppointmentDate, AppointmentTime 
			from view_upcoming_appointments

		end try
		begin catch
			throw
		end catch
	end