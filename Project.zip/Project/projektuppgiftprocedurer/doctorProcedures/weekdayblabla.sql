select GETDATE()
set datefirst 1
declare @day_in_week int
declare @first_date_next_week date
declare @last_date_next_week date
set @day_in_week = datepart(dw, getdate())
set @first_date_next_week = getdate() - @day_in_week + 7 + 1
set @last_date_next_week = dateadd(day, 4, @first_date_next_week)
select @first_date_next_week, @last_date_next_week