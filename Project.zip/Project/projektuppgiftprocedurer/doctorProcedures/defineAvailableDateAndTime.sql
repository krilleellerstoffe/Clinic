create procedure define_available_times(
	@p_employee_id char(5),
	@p_available_date date,
	@p_available_time time,
	@p_time_available bit)
	as
	begin
		begin try

			begin transaction

			--checks if the employee id exists in the doctor table, throws error if not
			if not exists(select 1 from Doctor where EmployeeId = @p_employee_id)
			begin
				raiserror('Employee id doesn''t exist.', 16, 1)
			end

			--checks if the date exists in the AvailableTime table, throws error if not
			if not exists(select 1 from AvailableTime where EmployeeId = @p_employee_id and AvailableDate = @p_available_date)
			begin
				raiserror('That date isn''t available.', 16, 1)
			end

			--checks if the time exists in the AvailableTime table, throws error if not
			if not exists(select 1 from AvailableTime where EmployeeId = @p_employee_id and AvailableDate = @p_available_date and AvailableTime = @p_available_time )
			begin
				raiserror('That time isn''t available for that date.', 16, 1)
			end

			--checks if the date and time is already booked and throws an error if so.
			if exists (select 1 from Appointment where EmployeeId = @p_employee_id and AppointmentDate = @p_available_date and AppointmentTime = @p_available_time)
			begin
				raiserror('The time can''t be changed. There''s already an appointment on that date and time.', 16, 1)
			end

			update AvailableTime
			set Booked = @p_time_available --0 if availablem, 1 if not
			where EmployeeId = @p_employee_id and AvailableDate = @p_available_date and AvailableTime = @p_available_time

			commit transaction
		
		end try
		begin catch
			rollback transaction;
			throw
		end catch
	end
