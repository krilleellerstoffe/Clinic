alter procedure delete_doctor
	@p_employee_id char(5)
	as
	begin
		declare @deleteerror int
		set @deleteerror = 0

		begin transaction
			delete from AvailableTime
			where EmployeeId = @p_employee_id
			set @deleteerror = @@ERROR

			if @deleteerror = 0
			begin
				delete from Appointment
				where EmployeeId = @p_employee_id
				set @deleteerror = @@ERROR
			end
			if @deleteerror = 0
			begin
				delete from MedicalRecord
				where EmployeeId = @p_employee_id
				set @deleteerror = @@ERROR
			end
			if @deleteerror = 0
			begin
				delete from Doctor
				where EmployeeId = @p_employee_id
				set @deleteerror = @@ERROR
			end
			if @deleteerror <> 0
			begin
				rollback transaction
			end
			else
			begin
				commit transaction
			end
		return @deleteerror
	end